This is a simple terminal color changing app based off the ASCII colors.
In order to use it simply import its class TermColor and access
the available colors in it. By adding the color as a first parameter in the
built-in print function you can modify the terminal output color.
